package com.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.java.Exceptions.InvalidResponseException;
import com.java.components.Loginbean;
import com.java.dao.MyDao;



//@Path("/student")
@RequestMapping("/student")
@Controller
public class RestfulController {
	@Autowired
MyDao obj;
	/*@GET
	@Produces(MediaType.TEXT_HTML)
	public String getTitle(){
		return "JAXRS";
	}
	
	@Path("/release")
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getRelease(){
		return "1.1";
	}
	
	@Path("/Validate")*/


@RequestMapping(method=RequestMethod.GET)
	@ResponseBody
	public ModelAndView validate(@ModelAttribute("bean")Loginbean bean1,BindingResult result
			){
		obj.save(bean1);
		
		ModelAndView mv=new ModelAndView("Valid");
		mv.addObject("bean2",bean1);
		if(result.hasErrors())//Can Specify Errors made inside hasErrors method
			return new ModelAndView("login");
		return mv;
	}

	
@RequestMapping(value="/{uid}",method=RequestMethod.GET)
@ResponseBody
	public String getStudent(@PathVariable("uid")String uid)
	{
		Loginbean bean1=obj.findByPK(uid);
		String str="";
		str=str+"Username:-"+bean1.getUsername()+"<br>";
		str=str+"Date:-"+bean1.getDate()+"<br>";
		str=str+"Books:-";
		for(String book:bean1.getBooks())
			str=str+book+",";
		str=str+"<br>"+"Quantity:-";
		for(String qty:bean1.getQuantity())
		{
			
			str=str+qty+",";
		}
		str=str+"<br>";
		return str;
	}
	
@RequestMapping(value="/{uid}",method=RequestMethod.PUT)
@ResponseBody
	public String updateStudent(@PathVariable("uid")String uid)
	{
	Loginbean bean1=obj.findByPK(uid);
	bean1.setUsername("Aakash");
	bean1.setPassword("aakash");
		obj.update(bean1);
		return "success";
	}
	
@RequestMapping(value="/{uid}",method=RequestMethod.DELETE)
@ResponseBody
	public String deleteStudent(@PathVariable("uid")String uid)
	{
	Loginbean bean1=obj.findByPK(uid);
		obj.delete(bean1);
		return "success";
	}
	
	
@RequestMapping(value="/all",method=RequestMethod.GET)
@ResponseBody
	public String getStudents()
	{
		List<Loginbean> bean=obj.findAll();
		String str="";
		for(Loginbean bean1:bean)
		{
			str=str+bean1.getUsername()+","+bean1.getDate()+","+bean1.getBooks()+","+bean1.getQuantity();
			str=str+"<br>";
		}
	return str;	
	}
	
	@RequestMapping(value="/all/offset={a}&limit={b}",method=RequestMethod.GET)
	@ResponseBody
	public String getStudentsPagination(@PathVariable("a")String a,@PathVariable("b")String b)
	{
		int offset=Integer.parseInt(a);
		int limit=Integer.parseInt(b);
		List<Loginbean> bean=obj.getAllPagination(offset, limit);
		String str="";
		for(Loginbean bean1:bean)
		{
			str=str+bean1.getUsername()+","+bean1.getDate()+","+bean1.getBooks()+","+bean1.getQuantity();
			str=str+"<br>";
		}
	return str;	
	}
	
	
	//SENDING RESPONSE OBJECT INSTEAD OF STRING
	
@RequestMapping(value="/responseTest/{id}",method=RequestMethod.GET)
@ResponseBody
public ResponseEntity<Loginbean> getResponse(@PathVariable("id")String id)
{
		Loginbean bean=obj.findByPK(id);
//		ErrorMessage err=new ErrorMessage(404,"Not Found");
		if(bean!=null)
		return new ResponseEntity<Loginbean>(bean,HttpStatus.OK);
//return Response.status(Status.OK).entity(err).build();
throw new InvalidResponseException("Resource Not Found");
}
}

