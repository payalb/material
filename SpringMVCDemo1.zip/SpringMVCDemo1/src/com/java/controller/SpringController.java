package com.java.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.java.components.Loginbean;
import com.java.dao.MyDao;

@Controller
public class SpringController {
	@Autowired
	MyDao daoObj;
/*@RequestMapping(method=RequestMethod.POST,path="/Welcome")*/
	@RequestMapping("/Welcome")
public ModelAndView send(){
	ModelAndView mv=new ModelAndView("Hello");
	mv.addObject("message","You are here");
	return mv;
}
/*	@RequestMapping("/Validate")//you can also write /Validate.html instead of /Validate 
public ModelAndView send2(@RequestParam("username")String name,@RequestParam("password")String password){
	ModelAndView mv=new ModelAndView("Valid");
	Loginbean lb=new Loginbean();
	lb.setUsername(name);
	lb.setPassword(password);
	mv.addObject("bean",lb);
	return mv;
}*/
	@RequestMapping("/Validate")//you can also write /Validate.html instead of /Validate 
public ModelAndView validate(@ModelAttribute("bean")Loginbean bean1,BindingResult result){
		daoObj.save(bean1);
		
		
	ModelAndView mv=new ModelAndView("Valid");
	mv.addObject("bean2",bean1);
	if(result.hasErrors())//Can Specify Errors made inside hasErrors method
		return new ModelAndView("login");
	return mv;
}
	@RequestMapping("/login")
public ModelAndView login(){
	ModelAndView mv=new ModelAndView("Login");
	return mv;
}
	@RequestMapping(method=RequestMethod.GET,path="/getStudent")
	public ModelAndView search(@RequestParam("id")String id)
	{
		Loginbean bean2=daoObj.findByPK(id);
		ModelAndView mv=new ModelAndView("Find");
		mv.addObject("bean3",bean2);
		return mv;
	}
/*	@RequestMapping(method=RequestMethod.DELETE,path="/deleteStudent")
	public ModelAndView delete(@RequestParam("id")String id)
	{
		Loginbean bean2=daoObj.findByPK(id);
		daoObj.delete(bean2);
		ModelAndView mv=new ModelAndView("Find");
		mv.addObject("bean3",bean2);
		return mv;
	}
	@RequestMapping(method=RequestMethod.PUT,path="/updateStudent")
	public ModelAndView update(@RequestParam("id")String id)
	{
		Loginbean bean2=daoObj.findByPK(id);
		bean2.setUsername("Nikhil");
		bean2.setPassword("Himanshu");
		daoObj.update(bean2);
		ModelAndView mv=new ModelAndView("Find");
		mv.addObject("bean3",bean2);
		return mv;
	}
	@RequestMapping(method=RequestMethod.GET,path="/getStudents")
	public ModelAndView getAll()
	{
//		Loginbean bean2=daoObj.findByPK(id);
		ModelAndView mv=new ModelAndView("Find");
		//mv.addObject("bean3",bean2);
		return mv;
	}*/
}
