package com.java.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;


import com.java.components.Loginbean;

@Repository
public class ImplementDAO implements MyDao{
	
@Autowired	
HibernateTemplate ht;
List<Loginbean> lb=new ArrayList<>();
Loginbean bean=new Loginbean();
	@Override
	public int save(Loginbean s) {
		// TODO Auto-generated method stub
		int i=Integer.parseInt((String) ht.save(s));
		return i;
	}

	@Override
	public boolean update(Loginbean s) {
		// TODO Auto-generated method stub
		ht.update(s);
		return true;
	}

	@Override
	public boolean delete(Loginbean s) {
		// TODO Auto-generated method stub
		ht.delete(s);
		return true;
	}

	@Override
	public List<Loginbean> findAll() {
		// TODO Auto-generated method stub
		/*DetachedCriteria dc=DetachedCriteria.forClass(Loginbean.class);
		List<Loginbean> lb=(List<Loginbean>)ht.findByCriteria(dc);
		return lb;*/
		ht.executeWithNewSession(new HibernateCallback<Object>() {

			@Override
			public Object doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				
				Query qselect=session.createQuery("from Loginbean");
				lb= (List<Loginbean>)qselect.list();
				return null;
			}
			
		});
		return lb;
	}

	@Override
	public Loginbean findByPK(String id) {
		// TODO Auto-generated method stub
	/*	Loginbean lb=(Loginbean) ht.get(Loginbean.class, id);
		return lb;*/
		
		ht.executeWithNewSession(new HibernateCallback<Object>() {

			@Override
			public Object doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				Criteria select=session.createCriteria(Loginbean.class);
				Criterion cr=Restrictions.eq("id",id);
				select.add(cr);
				Object m=select.uniqueResult();
				bean=(Loginbean)m;
				 
				return null;
			}
			
		});
		return bean;
		
	}
	
	@Override
	public List<Loginbean> getAllPagination(int offset,int limit) {
		// TODO Auto-generated method stub
		/*DetachedCriteria dc=DetachedCriteria.forClass(Loginbean.class);
		List<Loginbean> lb=(List<Loginbean>)ht.findByCriteria(dc, offset, limit);
			return lb;*/
		
		ht.executeWithNewSession(new HibernateCallback<Object>() {

			@Override
			public Object doInHibernate(Session session) throws HibernateException,
					SQLException {
				// TODO Auto-generated method stub
				Query qselect=session.createQuery("From Loginbean");
				qselect.setFirstResult(offset);
				qselect.setMaxResults(limit);
				 lb=(List<Loginbean>)qselect.list();
				 return null;
			}
			
		});
		return lb;
	}

	@Override
	public List<Loginbean> findbyname(String name) {
		// TODO Auto-generated method stub
		// Use projections and criterias and criterion
		return null;
	}

	@Override
	public Loginbean findByAdress(String location) {
		// TODO Auto-generated method stub
		// Use projections and criterias and criterion
		return null;
	}
}
