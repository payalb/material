package com.java.dao;

import java.util.List;

import com.java.components.Loginbean;

public interface MyDao {
public int save(Loginbean s);
public boolean update(Loginbean s);
public boolean delete(Loginbean s);
public List<Loginbean> findbyname(String name);
public Loginbean findByAdress(String location);
public Loginbean findByPK(String id);
public List<Loginbean> findAll();
public List<Loginbean> getAllPagination(int offset,int limit);
}
