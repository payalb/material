package com.java.Exceptions;

public class InvalidResponseException extends RuntimeException 
{

/**
	 * 
	 */
	private static final long serialVersionUID = -4280044455728976231L;

public InvalidResponseException(String message)
{
	super(message);
}
}
