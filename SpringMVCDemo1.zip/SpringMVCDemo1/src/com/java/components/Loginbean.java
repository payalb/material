package com.java.components;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
@Entity
public class Loginbean {	
String username;
String password;
String date;
@ElementCollection(fetch=FetchType.EAGER)
Set<String> books=new HashSet<>();//must be initialized to change the fetch type from lazy to eager
@ElementCollection(fetch=FetchType.EAGER)                //initializations prevent LazyInitializationException
List<String> quantity=new ArrayList<String>();//must be initialized to change the fetch type from lazy to eager
@Id
String id;
/*@OneToOne(cascade=CascadeType.ALL)
Address address;*/
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public Set<String> getBooks() {
	return books;
}
public void setBooks(Set<String> books) {
	this.books = books;
}
public List<String> getQuantity() {
	return quantity;
}
public void setQuantity(List<String> quantity) {
	this.quantity = quantity;
}
/*public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}*/
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
}
